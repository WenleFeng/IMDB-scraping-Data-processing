import scrapy
from scrapy.loader import ItemLoader
from imdb.items import ImdbItem
class imdbSpider(scrapy.Spider):
	name = 'imdb'

	start_urls = ['https://www.imdb.com/list/ls057823854/?sort=release_date,asc&st_dt=&mode=detail&page=1']


	def parse(self, response):
		for info in response.selector.xpath('//div[@class="lister-item mode-detail"]/div[2]'):
			loader = ItemLoader(item = ImdbItem(), selector=info, response=response)
			loader.add_xpath('name', './/h3/a/text()')
			loader.add_xpath('year', './/h3/span[2]/text()')
			loader.add_xpath('director', './/p[3]/a[contains(@href,"_dr_")]/text()')
			loader.add_xpath('star', './/p[3]/a[contains(@href,"_st_")]/text()' )
			loader.add_xpath('rating', './/div[1]/div[1]/span[@class="ipl-rating-star__rating"]/text()' )

			yield loader.load_item()



		next_page = response.selector.xpath('//a[@class="flat-button lister-page-next next-page"]/@href').extract_first();
		if next_page is not None:
			next_page_link = response.urljoin(next_page)
			yield scrapy.Request(url=next_page_link, callback=self.parse)