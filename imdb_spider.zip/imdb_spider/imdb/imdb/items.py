# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html


import scrapy
from scrapy.loader.processors import MapCompose, TakeFirst, Join
from w3lib.html import remove_tags
import re

def remove_quotations(value):
	return re.sub(r'[^0-9]+', r'', value)

def strip_value(value):
	return value.strip()


class ImdbItem(scrapy.Item):
    name = scrapy.Field(
    	)
    year = scrapy.Field(
    	input_processor = MapCompose(remove_quotations),
    	output_processor = TakeFirst()
    	)
    director = scrapy.Field(
    	)
    star = scrapy.Field(
    	)
    rating = scrapy.Field(
    	)